﻿ # -*- coding: utf-8 -*-
import requests
import os
import shutil
import time
import re
import codecs

def check(f1,f2):
    for each1 in f1:
        if '<td style="padding-left:8px"> <a href="/sapprft/zongshu/serviceContent2.shtm' in each1:
            s = each1
            m = s[98:]
            af = '>(.*)</a></td>'
            if af:
                a1=re.findall(af,m)
                txt = a1[0].strip()
            str2 = txt
            break
    # print str2
    resultstr = checkresult(str2,f2)
    if resultstr == "OK":
        return "OK"
    else:
        return "NO"

def checkresult(str1,f1):
    for each1 in f1:
        if str1 in each1:
            return "OK"
    return "NO"

def Update(num1):
    for i in range(1,num1):
        fileName1 = os.path.join("data1", str(i) + ".data")
        f = open("ok.csv","a")
        f1 = open(fileName1,"r") 
        # print fileName1
        for ec in f1:
            eachLine = ec
            if '<td style="padding-left:8px"> <a href="/sapprft/zongshu/serviceContent2.shtm' in eachLine:
                s = eachLine
                m = s[98:]
                af = '>(.*)</a></td>'
                a1=re.findall(af,m)
                txt = a1[0].strip()
                # print txt
                f.write(txt)
                f.write(',')
            elif '<td style="padding-left:8px">' in eachLine and "href" not in eachLine and "convertdate" not in eachLine:
                e = eachLine
                af = '<td style="padding-left:8px">(.*)</td>'
                aa=re.findall(af,e)
                if aa:
                    txt1 = aa[0].strip()
                    f.write(txt1)
                    f.write(',')
                else:
                    af1 = '<td style="padding-left:8px">(.*)'
                    aa1 = re.findall(af1,e)
                    txt2 = aa1[0].strip()
                    f.write(txt2)
                    f.write(',')
            elif "convertdate" in eachLine:
                e = eachLine
                af = '<td style="padding-left:8px"> <span id="convertdate">(.*)</span></td>'
                a2=re.findall(af,e)
                txt2 = a2[0].strip()
                f.write(txt2)
                f.write('\n')
        f1.close()
        f.close()

def Merge(f1,f2):
    fo1 = codecs.open(f1, "r", 'utf-8-sig')
    fo2 = codecs.open(f2, "r", 'utf-8')
    fo3 = codecs.open("res1.csv", "w", 'utf-8')
    for e in fo2:
        fo3.write(e)
    for e in fo1:
        fo3.write(e)
    fo1.close()
    fo2.close()
    fo3.close()
    fo3 = codecs.open("res1.csv", "r", 'utf-8')
    fo1 = codecs.open(f1, 'w', 'utf-8-sig')
    for e in fo3:
        fo1.write(e)
    fo1.close()
    fo3.close()

def FirstData(file):
    f = codecs.open(file, 'r', 'utf-8-sig')
    for line in f:
        txt1 = line
        break
    f.close()
    str1 = txt1.split(',')
    return str1[0]


def UpdateSingal(num):
    fileName = os.path.join("data1", str(num) + ".data")
    f1 = codecs.open(fileName, 'r', 'utf-8')
    f2 = codecs.open("ok.csv",'a', 'utf-8')
    txt7 = FirstData("result.csv")
    for each1 in f1:
            eachLine = each1
            if '<td style="padding-left:8px"> <a href="/sapprft/zongshu/serviceContent2.shtm' in eachLine:
                s = eachLine
                m = s[98:]
                af = '>(.*)</a></td>'
                a1=re.findall(af,m)
                if a1[0] == txt7:
                    return 
                # print txt
                f2.write(a1[0])
                f2.write(',')
            elif '<td style="padding-left:8px">' in eachLine and "href" not in eachLine and "convertdate" not in eachLine:
                e = eachLine
                af = '<td style="padding-left:8px">(.*)</td>'
                aa=re.findall(af,e)
                if aa:
                    txt1 = aa[0].strip()
                    f2.write(txt1)
                    f2.write(',')
                else:
                    af1 = '<td style="padding-left:8px">(.*)'
                    aa1 = re.findall(af1,e)
                    txt2 = aa1[0].strip()
                    f2.write(txt2)
                    f2.write(',')
            elif "convertdate" in eachLine:
                e = eachLine
                af = '<td style="padding-left:8px"> <span id="convertdate">(.*)</span></td>'
                a2=re.findall(af,e)
                txt2 = a2[0].strip()
                f2.write(txt2)
                f2.write('\n')
    f1.close()
    f2.close()    

if os.path.exists("data1"):
    shutil.rmtree("data1",True)
os.mkdir("data1")
updateflag = 0
for num in range(1, 693):
    payload = {'pageNodeID':'3966', 
    'pageContentID':'0', 
    'pageTemplateID':'1610', 
    'isPageRefresh':'False', 
    'pageUrl':'7e2NgF3U02dai0cwLqW7hoHtWkqYQ0slash0qga6g4DsnvRbqt8B0add0CToNPQM7Jt5xJvgNguVyelhz0slash0x3A0equals0', 
    'ajaxDivID':'ajaxElement_1_705', 
    'templateContent':'hFTXzDxfMOP0JKMFNqVqE5TEnG7fhacAFgX6R0HQARPz0add0HFBDuM0slash00slash00add0lDvl9lR0MMP0slash0op75rhU7X0rucwxrMgvvDmfFeScCu6Qpd6K89sZ3qpS8mbRqM1n3UFg1a3j0add0uXecCWEP9gqkRQcB4x4iT2iJSm0add0cB5fb1QDhCBSkw6ddKbpbfQgytRakdqA0slash0juN0PtfofiIzRJbSXjlXz7ZSRfsm0add0xDAOOkYuxzYA8wwjNovu0slash0mcjleCb83nSzYa6PBVDaptvLk1C3duUrCbM56LcxL8bMtR0jzD0ZiGoWojQHzRImuEZADpmNvAit1cdXyqSJDcgUp7FamzeRg0add0uHNP7SiIUbc5g8Uj0add05TlBTmRnF4F1Te0add04gbOxSnlCp5smxeCCyq7fP3MSMYbhmf4khdX09AMiAvoQZTaTE0slash0qtxmdqr3vbHFsCacfX3rWxfV4ZLV0J0HSjd0N2QVrIwdZ3jQs5D1lcYDpc5QiraU0slash0uWPSMLyXJpawuVXIKY2HvHWu48Y98rF8XxIFGhfTAfV8tn6l42TqTfITVrJmvQ4TbW6NzWyK0add02HhJHwMdeJNY90Ho74X00add0Z6Gbu4x7Q0zCTaDCTFqh0slash00slash0N0Y9D0bnrnajfrWCnwuMVj2cfa0add0xyEE9cCZf0add0NDkbXfisEeD5LgsK2i4zh5M0slash0EbEyRlCkR5egHaqk0t8JgNnsjkHwWXZYMALo3KxmZOydbReyodV8xgKDWSsQU1UHrRHh6m4yVPoXRwBsl0add0c5HsSLfFePBr4jRdmutIvkKgGS0slash0sYGpB1s24LKFUb14QcjCtp2r13A9UISN30ZHIj3ANQ04s5QDESq9DjlonBxGrbwUMqI0add0bcS5WtCj2XzN6EXcFPcNyUMPHZcCTiHW0add05UjQSD5i59NoSLg54Y9gsLD9mK320slash04mDp1zjyz4tiuzY1xdKwXd24uY0ZK3JYUb5AzGSamnr6B4hcTFNVqRClTj3PXu7YgzC3TFi7DvsbgyQOb15GaCkmfXP6rgqmULQe0jUaDe4zFXPgyW4ydpP0slash0W12aIhBcs0F59kWepTZzSUSrdmm1i3K64nIB2ZS3hWODqDIDCcmHV0add08sL3uJ4EKggCGaRNBIa70add0URe7WeY8mswMbibJM9YU9VfjRmK28K6dDx99vGV2uhvrBQLiop9pmFjRWymM0add0F0slash0hyS6rcmgwEm9aT0slash0yvWvLUMA4hd9irgK4kuu9nwwJFzx90slash0Z60add0dm1SCpJv3PnDpIecBWaIDjUZJA7SLbWBx8Xni3C02QXKYHqCDx9BFmXzaTjkwaQRvf3GDvydwJwNmVrkiuIUegeyPn0add0DuRuwuvPZbhUqatXArDwLD9c2QJMGwGW3ZoLTS0acLIYLNz0slash06q0add0B80slash0vLNQPz9Gj2GQSjBZZ0QbAngYTRIKhFgILslbEBv0add04WL0add0d5cPeNej4WZwX7Lbe3O2fBVdl6YhGr0slash0SJ2Gib0slash0ZIqSfVx8DNALXBkESiJr0slash0TwZd5MDJRCsbDTm2Rze2L0add0GmX0add0uT0slash00add0u1YYGWSEU50SC2RgfKArS2BE2d0QAVYvzDSpPvJkMfMaYvammzgatxbflJaQALNBEv37KULh2ol5ALmMw9fFJtRPAkZhwzbZJMT0slash0Sfu0slash0EyEtu6HebEFkNAgOh1qeQoLWlsNHA7x2Y58JtOE1k5S0bOPcjlSq1im0slash0zXVz1v0slash0plBgvm6sWeZEKrhsvJpM0P7zstPZrWWnVhQPKmGU08XRykWJ9H5tTk7xvVJuWmbDMneCuZlyO1PnKsBkJ0add0CWfw30slash0moiktU6E510gfZC4vr61jzTWzhFsaU0vkTl9s6TspQrdKn2JapuMX7wsmu9OXjgYn8gW3GkjcfsBL0S3OXuzuV8ktGV6OVMehE0slash0nW8UlMpE8J1XpEkFcdu3WYbAblk8pM0jYL0slash03DYVCRtJCQtnFzmkOP40slash0OwkiUc65nxZJhufK3x6zdRRUL15UF3mV878aOM7yQ8awWkl30slash0d59LZohebjL8quBkrZcjIxcsF8Im0slash09G8F2nOwHMMvj2CWXsqpuPjv1wkZa0add0phKgBYnLrdrHtF8ICFB16kW0rn72oeUFiH3zZYm9Eb73PpQY0add0IrlL0add0YFCWaft9y4iEHq0add0Z1U10slash0EyEI6zABxMrbv0slash0Gk3Rwij37Pjx5aBM9EOmB8GPEZ5T37jd6iujHoOmbp780nYvIrI8ce6EIXbM8qQZhuRVT5knuXXtYynjNyiME4Lhs0gP5mWvktK7VLAjdLiHAswUagisUybaEqSMxjOh4D1d1hzYI6klK8Of0BwpCUJrtQmM22579RBVjLsU8KHdxKVwUT6LyIq6IUpz4KbStCIylyACOBOGFDuIB0slash0Q0SXhG0h3Dd6QebWey06uk0slash078nsdw5jbGtupbmkkgnN2itOzZ9hhU2lLnoZ8EHhhUX5dz9Isl4XyExt2xkYTiHQHBngRyzwsKYrGRj30N0slash02yun8FoCUpGwqJ5L8BB0slash0so94R3IESaaF0aifeteYAjuS2h0add02ZQK0Ir3oeHNzsdPOhxxd5pJieqfa80liSoJdOLGGUG9Iexf0myVazOykgBURbjl1XKyXDdKN7RUlcDg07EJQ1GK8f6otz3SJyb4yrJL6r9jV6zA6nvJM90slash0DE8HJw8AsXUqb0add0y7j0add0ZXRp1AU5UWsWyIyicDtllZcJS42eihEq2A1XYq0slash00slash0c0bbDo9RAa90add0KMou6M66vhocHKM5r9rLmMtf2R6xnGvsuYQLYqxrpSm0slash08OUmNk0slash0sO0add0o5Sdr7NCjyVED0add0jqlpDvGrYRxb1JGarY6xyFJtMNrZUCHi0VFMH70add0pgYdTs9DrJPKNGXxu2cp0uWqYTDnKfRe0slash0hcEkyyC0slash0tkIzbFdanvI4cHV5QRWYHlUKzfjQG7kxG4fRH9cBNwbmRKH1BxRZg9cWdDuTQvLhWYTBjznJwEYbDqvZ4g0slash0BDNxTPRkeDIvYjMrX8vQjqcuoVL6ozReSFfioGACnWd80slash0ByuJsTgTtzTEyAc9f0VTOjVAneIC4K0slash0Z08D1YfrJNw3KheL0add0NP18oIYTW8ippkzrfGWDkMIbMj9NDIxiWDU8rzpvZbgj430slash0yOgeagyeJjpc2ugzTBy5VpNgYrdEVNFa5yFHENvnILjze3rYeas785X0kWS0add0R3tc7D4r98Ljrht1EGQCbw9OwMPkArEKuztWDw1v02090slash0p23PqhS7po0slash00add0MaSyu1HHpbWZ6BXvFXC6RO023qzr0WtDjjOyWdZsF2PhnwMEVZmoDvGJ8xN4qL0bMwctQjoKKvsk07lDkxOaok4ox01A0add0RP3YKSIkGA2kv0slash0bomf5a8VUDmJT9tzuT0add0gSPBn3dtrkkqSMCnQFZ7DyM3puLW1Paet8h2sUaXEO5XI4D4QSuM3QkBkADAJtUaKJ0slash06J64Dv10RDpG0M3irhWUbP6SvhSFUKL0WX4ijjwzkqrFR6pZvDt2t5jwoUlBE8ByK2KSSOLlAfgbSx8V0slash00slash0CG2pteiIt0slash0g2UgHggX2IwT0B1n9q98F8XDh45pjVYFEvoOG7jcitRHQD0slash0EaaDQVIN2TruMZtEVOHPzKKYtR0zj0bB4zYaNwRzYNmyZfIUU1E0slash0glU9hMhreT0add0jefq7Qitv0slash0NWtmiVAD9yW58khb0slash0J7z5KlZYWmP0add0b0add0Ta0EFfc0R0slash03cjxkal5CrWnxjujry0add0M8y5P3RwCXDeC5xT50zAKH1msQ0add0syCN0slash0LQVIfememJ1Y0slash0hztF2Ff6nFZLS0VBUh4dPxQhUQCYSUupS0wl6KYVm8fV0slash0PRfmUJcQl1ewJN2aN0slash0rH4d178lynRle4YVHTvQ3Kmq0saRbNEEoNq7YkT98nfT5x45vpkcsWpeXas6EbctvwIDALPkF982FZOnLsX7XSzKAHBm3eRQTgZ7p2fvLAqfkVItbzExqcmCwsOq1Q5wqRg0tuCKVHpGHGWN60add0eErHqXVJGGq1fMLAcL50slash00slash0FTzw7i06BQgGXP8aTRRZiO2hsRlfIT6lqrtvL4scPbznz5ENEzyaDWFriOZCIOuKyVjqo0DpscQehnXkEFcCp0add0siG1o7WHu5nF8EXcVlnmX9kWrY0equals0', 
    'timeStamp':str(time.time()*1000), 
    'pageNum':str(num)}
    r = requests.post("http://www.sapprft.gov.cn/sitefiles/services/wcm/dynamic/output.aspx?publishmentSystemID=3966&FileName=&PublishingUnit=&OperationUnit=&DocumentNumber=", data=payload)
    # print r.text
    message = os.path.join("正在抓取第", str(num) + "个文件")
    fileName = os.path.join("data1", str(num) + ".data")
    f = open(fileName, "w")
    f.write(r.text.encode('utf-8'))
    f.close()
    f1 = open(fileName, "r")
    f2 = open("result.csv","r")
    resultstr = check(f1,f2)
    f1.close()
    f2.close()
    print message.decode("utf-8").encode("gb2312")
    if resultstr == "OK" and num == 1:
        break
    elif resultstr == "NO":
        updateflag = 1
    elif resultstr == "OK" and updateflag == 1:
        break
# print str(num)
if num > 1:
    Update(num-1)
    UpdateSingal(num-1)
    Merge("result.csv","ok.csv")
    print "更新已完成".decode("utf-8").encode("gb2312")
    os.remove("res1.csv")
    os.remove("ok.csv")
else:    
    print "本次无更新".decode("utf-8").encode("gb2312")
shutil.rmtree("data1",True)